library(testthat)

test_that("Parallel execution of expensive_function", {
  cl <- parallel::makeCluster(2) # Create a cluster with 2 cores
  on.exit(parallel::stopCluster(cl)) # Ensure cleanup

  results <- parallel::parLapply(cl, 1:5, expensive_function)
  expect_equal(unlist(results), c(1, 4, 9, 16, 25))
})
