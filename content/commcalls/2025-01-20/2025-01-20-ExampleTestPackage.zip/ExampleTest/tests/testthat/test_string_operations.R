library(testthat)

test_that("String concatenation works correctly", {
  expect_equal(concatenate_strings("Hello", "World"), "Hello World")
  expect_equal(concatenate_strings("", "Test"), " Test")
  expect_error(concatenate_strings(1, "Test"), "Both inputs must be character strings.")
})
