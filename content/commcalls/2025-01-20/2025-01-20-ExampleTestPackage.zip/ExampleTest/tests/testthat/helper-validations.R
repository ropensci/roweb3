#' Validate Numeric Input
#' @param x Input to validate.
#' @return TRUE if valid, otherwise an error.
validate_numeric <- function(x) {
  if (!is.numeric(x)) stop("Input must be numeric.")
  TRUE
}

#' Temporary File Helper
#' @param code Code block to execute with a temporary file.
with_temp_file <- function(code) {
  temp_file <- tempfile()
  on.exit(unlink(temp_file), add = TRUE)
  code(temp_file)
}
