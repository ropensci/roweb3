library(testthat)

test_that("Statistical calculations are correct", {
  data <- c(1, 2, 3, 4, 5)
  stats <- calculate_stats(data)

  expect_equal(stats$mean, 3)
  expect_equal(stats$sd, 1.58113883)

  expect_error(calculate_stats("not numeric"), "Input must be a numeric vector.")
  expect_error(calculate_stats(NULL), "Input must be a numeric vector.")
})
