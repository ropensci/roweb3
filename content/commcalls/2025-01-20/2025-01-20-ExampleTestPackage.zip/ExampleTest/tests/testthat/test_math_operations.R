library(testthat)

test_that("Addition works correctly", {
  expect_equal(add_numbers(1, 2), 3)
  expect_equal(add_numbers(-1, 1), 0)
  expect_error(add_numbers("a", 1), "Both inputs must be numeric.")
})

test_that("Subtraction works correctly", {
  expect_equal(subtract_numbers(5, 3), 2)
  expect_equal(subtract_numbers(0, 1), -1)
  expect_error(subtract_numbers(5, "b"), "Both inputs must be numeric.")
})
