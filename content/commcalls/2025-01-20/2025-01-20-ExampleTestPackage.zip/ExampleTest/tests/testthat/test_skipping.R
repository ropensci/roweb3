library(testthat)

test_that("API check skips if offline", {
  skip_if_offline()
  expect_error(check_api_response("https://some-api-url.com"))
})

test_that("Test skipped on unsupported OS", {
  skip_on_os("windows")
  expect_true(Sys.info()["sysname"] != "Windows")
})
