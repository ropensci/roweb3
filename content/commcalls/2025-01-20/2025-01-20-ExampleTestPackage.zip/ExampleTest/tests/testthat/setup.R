# The  setup.R  file is executed before running tests. It is a good place to load libraries and set up the environment for the tests.
# The  teardown.R  file is executed after running tests. It is a good place to clean up the environment after the tests.
cat("Code executed before running tests. This is setup.R\n")
