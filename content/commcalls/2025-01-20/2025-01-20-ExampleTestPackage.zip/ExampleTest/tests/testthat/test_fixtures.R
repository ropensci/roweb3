library(testthat)

test_that("Temporary file handling works", {
  with_temp_file(function(temp_file) {
    write_data_to_file(temp_file, "Test content")
    expect_true(file.exists(temp_file))
    expect_equal(readLines(temp_file), "Test content")
  })
})
