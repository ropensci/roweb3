library(testthat)

test_that("Data frame snapshot remains consistent", {
  expect_snapshot_value(generate_dataframe(), style = "json2") # Compatible style
})

test_that("Snapshot with large data", {
  set.seed(123) # Ensure reproducibility
  large_df <- data.frame(id = 1:1000, value = rnorm(1000))
  expect_snapshot_value(large_df, style = "json2")
})
