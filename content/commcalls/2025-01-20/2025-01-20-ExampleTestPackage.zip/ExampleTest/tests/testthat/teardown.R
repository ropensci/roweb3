cat("Code executed after running tests. This is teardown.R\n")
