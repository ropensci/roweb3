library(testthat)

test_that("Validate numeric input correctly", {
  expect_true(validate_numeric(5))
  expect_error(validate_numeric("abc"), "Input must be numeric.")
})
