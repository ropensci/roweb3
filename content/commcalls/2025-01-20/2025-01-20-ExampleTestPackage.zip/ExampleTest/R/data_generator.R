#' Generate Sample Data Frame
#' @return A data frame with sample data.
#' @examples
#' generate_dataframe()
generate_dataframe <- function() {
  data.frame(
    id = 1:3,
    name = c("Alice", "Bob", "Charlie"),
    score = c(85, 92, 78)
  )
}
