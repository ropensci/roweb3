#' Check API Response
#' @param url A character string representing the API URL.
#' @return Response status or error.
#' @examples
#' check_api_response("https://example.com")
check_api_response <- function(url) {
  httr::GET(url)
}
