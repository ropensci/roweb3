#' Calculate Mean and Standard Deviation
#' @param x A numeric vector.
#' @return A list containing the mean and standard deviation of the input vector.
#' @examples
#' calculate_stats(c(1, 2, 3, 4, 5))
calculate_stats <- function(x) {
  if (!is.numeric(x)) stop("Input must be a numeric vector.")
  list(mean = mean(x), sd = sd(x))
}
