#' Write Data to File
#' @param file_path File path to write data.
#' @param content Data to write.
#' @return TRUE if successful.
write_data_to_file <- function(file_path, content) {
  writeLines(content, file_path)
  TRUE
}
