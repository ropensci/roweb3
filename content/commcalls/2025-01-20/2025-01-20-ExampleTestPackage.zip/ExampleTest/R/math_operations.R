#' Add Two Numbers
#' @param x A numeric value.
#' @param y A numeric value.
#' @return The sum of x and y.
#' @examples
#' add_numbers(1, 2)
add_numbers <- function(x, y) {
  if (!is.numeric(x) || !is.numeric(y)) stop("Both inputs must be numeric.")
  x + y
}

#' Subtract Two Numbers
#' @param x A numeric value.
#' @param y A numeric value.
#' @return The difference of x and y.
#' @examples
#' subtract_numbers(5, 3)
subtract_numbers <- function(x, y) {
  if (!is.numeric(x) || !is.numeric(y)) stop("Both inputs must be numeric.")
  x - y
}

#' Perform Expensive Computation
#' @param x A numeric value.
#' @return The square of the input.
#' @examples
#' expensive_function(2)
expensive_function <- function(x) {
  Sys.sleep(1) # Simulate a delay
  x^2
}

