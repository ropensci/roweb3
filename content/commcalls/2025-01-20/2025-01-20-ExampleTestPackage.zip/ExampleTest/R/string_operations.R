#' Concatenate Strings
#' @param x A character string.
#' @param y A character string.
#' @return A single concatenated string.
#' @examples
#' concatenate_strings("Hello", "World")
concatenate_strings <- function(x, y) {
  if (!is.character(x) || !is.character(y)) stop("Both inputs must be character strings.")
  paste(x, y, sep = " ")
}
